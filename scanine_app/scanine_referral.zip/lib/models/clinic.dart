import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// One veterinary clinic, loaded from assets/clinics.json.
class Clinic {
  final String name;
  final String? address;
  final String? phone;
  final String? hours;
  final String? services;
  final double? lat;
  final double? lon;
  final bool verified;

  const Clinic({
    required this.name,
    this.address,
    this.phone,
    this.hours,
    this.services,
    this.lat,
    this.lon,
    this.verified = false,
  });

  bool get hasPin => lat != null && lon != null;
  bool get canCall => phone != null && phone!.trim().isNotEmpty;

  /// What the Directions button searches for. Deliberately the address
  /// string rather than the stored coordinates — those are approximate,
  /// and letting the map app geocode the real address means an imprecise
  /// pin can never route someone to the wrong building.
  String get mapQuery =>
      address != null && address!.trim().isNotEmpty
          ? address!
          : '$name, Tacloban City, Leyte';

  factory Clinic.fromJson(Map<String, dynamic> j) => Clinic(
        name: j['name'] as String,
        address: j['address'] as String?,
        phone: j['phone'] as String?,
        hours: j['hours'] as String?,
        services: j['services'] as String?,
        lat: (j['lat'] as num?)?.toDouble(),
        lon: (j['lon'] as num?)?.toDouble(),
        verified: (j['verified'] as bool?) ?? false,
      );

  static Future<List<Clinic>> loadAll() async {
    final raw = await rootBundle.loadString('assets/clinics.json');
    final decoded = json.decode(raw) as Map<String, dynamic>;
    return (decoded['clinics'] as List)
        .map((e) => Clinic.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
