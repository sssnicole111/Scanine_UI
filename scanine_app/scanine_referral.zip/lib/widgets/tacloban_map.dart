import 'package:flutter/material.dart';

import '../models/clinic.dart';
import '../theme/tokens.dart';

/// Bounding box the schematic is drawn to. Latitude/longitude are projected
/// linearly into the 335x190 drawing space.
const double _latTop = 11.2530;
const double _latBottom = 11.2320;
const double _lonLeft = 124.9930;
const double _lonRight = 125.0130;

const double _vbW = 335;
const double _vbH = 190;
const double _pinR = 11;

/// A hand-drawn locator map of Tacloban.
///
/// Deliberately not a tile map: Scanine claims to work with no connection,
/// and a live map would need network and an API key. This orients the user
/// offline; real navigation is handed off to their map app by address.
class TaclobanMap extends StatelessWidget {
  const TaclobanMap({
    super.key,
    required this.clinics,
    required this.selected,
    required this.onPinTap,
  });

  final List<Clinic> clinics;
  final int selected;
  final ValueChanged<int> onPinTap;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: _vbW / _vbH,
      child: LayoutBuilder(
        builder: (context, box) {
          final sx = box.maxWidth / _vbW;
          final sy = box.maxHeight / _vbH;

          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(painter: _MapPainter()),
              ),
              for (var i = 0; i < clinics.length; i++)
                if (clinics[i].hasPin)
                  Positioned(
                    left: _projectX(clinics[i].lon!) * sx - _pinR,
                    top: _projectY(clinics[i].lat!) * sy - _pinR,
                    child: _Pin(
                      number: i + 1,
                      active: i == selected,
                      onTap: () => onPinTap(i),
                    ),
                  ),
              const Positioned(
                left: 10,
                bottom: 8,
                child: Text(
                  'Schematic · not to scale',
                  style: TextStyle(
                    fontSize: 9,
                    color: Color(0x8CFFFFFF),
                    letterSpacing: 0.3,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  static double _projectX(double lon) =>
      ((lon - _lonLeft) / (_lonRight - _lonLeft) * _vbW).clamp(_pinR, _vbW - _pinR);

  static double _projectY(double lat) =>
      ((_latTop - lat) / (_latTop - _latBottom) * _vbH).clamp(_pinR, _vbH - _pinR);
}

class _Pin extends StatelessWidget {
  const _Pin({required this.number, required this.active, required this.onTap});

  final int number;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: _pinR * 2,
        height: _pinR * 2,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: active ? T.amber : T.amber.withAlpha(140),
          border: Border.all(color: T.navy, width: 2.5),
        ),
        alignment: Alignment.center,
        child: Text(
          '$number',
          style: const TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w700,
            color: T.navy,
          ),
        ),
      ),
    );
  }
}

class _MapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / _vbW, size.height / _vbH);

    // land
    canvas.drawRect(
      const Rect.fromLTWH(0, 0, _vbW, _vbH),
      Paint()..color = T.navy,
    );

    final water = Paint()..color = T.navy2;

    // Cancabato Bay, lower left
    final bay = Path()
      ..moveTo(0, 190)
      ..lineTo(0, 96)
      ..cubicTo(40, 104, 78, 128, 104, 152)
      ..cubicTo(120, 167, 128, 180, 132, 190)
      ..close();
    canvas.drawPath(bay, water);

    // San Juanico Strait, upper left
    final strait = Path()
      ..moveTo(0, 0)
      ..lineTo(128, 0)
      ..cubicTo(112, 22, 86, 38, 52, 46)
      ..cubicTo(34, 50, 14, 52, 0, 52)
      ..close();
    canvas.drawPath(strait, water);

    // roads
    void road(Path p, double w) => canvas.drawPath(
          p,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = w
            ..strokeCap = StrokeCap.round
            ..color = const Color(0x29FFFFFF),
        );

    road(
      Path()
        ..moveTo(138, 190)
        ..cubicTo(150, 150, 168, 116, 196, 92)
        ..cubicTo(222, 70, 262, 56, 335, 48),
      3,
    );
    road(
      Path()
        ..moveTo(108, 60)
        ..cubicTo(146, 74, 178, 96, 206, 126)
        ..cubicTo(222, 143, 236, 166, 244, 190),
      2,
    );
    road(
      Path()
        ..moveTo(186, 22)
        ..cubicTo(192, 62, 196, 108, 200, 190),
      1.6,
    );
    road(
      Path()
        ..moveTo(120, 128)
        ..cubicTo(168, 118, 226, 112, 335, 110),
      1.6,
    );
    road(
      Path()
        ..moveTo(250, 34)
        ..cubicTo(258, 78, 266, 130, 272, 190),
      1.2,
    );

    _label(canvas, 'Cancabato Bay', 28, 176, 8);
    _label(canvas, 'San Juanico Strait', 24, 22, 8);

    canvas.restore();
  }

  void _label(Canvas canvas, String text, double x, double y, double size) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontSize: size,
          color: const Color(0x4DFFFFFF),
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(x, y - size));
  }

  @override
  bool shouldRepaint(covariant _MapPainter oldDelegate) => false;
}
