/// The Analyzing screen: Grad-CAM heat laid over the whole photo as a lit grid.
library;

export 'src/debug/analyzing_debug_page.dart';
export 'src/debug/fixture_cams.dart';
export 'src/domain/analyze_timeline.dart';
export 'src/domain/heat_grid.dart';
export 'src/domain/input_mapping.dart';
export 'src/domain/scan_trace.dart';
export 'src/ui/analyze_clock.dart' show AnalyzingConfig, AnalyzingHeroTags;
export 'src/ui/analyzing_route.dart';
export 'src/ui/analyzing_screen.dart';
export 'src/ui/analyzing_tokens.dart';
export 'src/ui/heat_overlay_image.dart';
