import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../domain/analyze_timeline.dart';
import '../domain/scan_trace.dart';
import '../ui/analyze_clock.dart';
import '../ui/analyzing_route.dart';
import '../ui/analyzing_screen.dart';
import 'fixture_cams.dart';

/// Debug-only page: run the Analyzing screen on built-in fixtures (one
/// cluster, several clusters, diffuse, empty) at 0.25x to 1x speed.
///
/// Register it only in debug builds:
/// ```dart
/// routes: {
///   if (kDebugMode) '/debug/analyzing': (_) => const AnalyzingDebugPage(),
/// }
/// ```
class AnalyzingDebugPage extends StatefulWidget {
  const AnalyzingDebugPage({super.key});

  @override
  State<AnalyzingDebugPage> createState() => _AnalyzingDebugPageState();
}

class _AnalyzingDebugPageState extends State<AnalyzingDebugPage> {
  static const double _w = 900;
  static const double _h = 1200; // 3:4 portrait, like a phone photo

  String _fixture = FixtureCams.severalClusters;
  double _speed = 1.0;
  AnalyzeMode? _mode;
  bool _slowInference = false;
  bool _busy = false;

  Future<void> _run() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final photo = await _syntheticPhoto(_fixture);
      if (!mounted) return;
      final trace = Future<ScanTrace>.delayed(
        Duration(milliseconds: _slowInference ? 2500 : 0),
        () => ScanTrace.fromCam(
          cam: FixtureCams.cam(_fixture),
          camWidth: FixtureCams.size,
          camHeight: FixtureCams.size,
        ),
      );
      final host = context;
      await Navigator.of(host).push(
        analyzingFadeRoute<void>(
          (_) => AnalyzingScreen(
            photo: photo,
            photoSize: const Size(_w, _h),
            trace: trace,
            config: AnalyzingConfig(
              speed: _speed,
              forceMode: _mode,
              detectLowEnd: false,
            ),
            onFinished: (ctx, t) {
              Navigator.of(ctx).pop();
              if (!host.mounted) return;
              ScaffoldMessenger.of(host).showSnackBar(
                SnackBar(
                  content: Text(
                    'Finished. coverage '
                    '${(t.coverage * 100).toStringAsFixed(1)} %, '
                    'diffuse: ${t.diffuse}',
                  ),
                ),
              );
            },
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(kDebugMode, 'AnalyzingDebugPage is for debug builds only.');
    return Scaffold(
      appBar: AppBar(title: const Text('Analyzing (debug)')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Fixture', style: Theme.of(context).textTheme.titleSmall),
          Wrap(
            spacing: 8,
            children: [
              for (final f in FixtureCams.names)
                ChoiceChip(
                  label: Text(f),
                  selected: _fixture == f,
                  onSelected: (_) => setState(() => _fixture = f),
                ),
            ],
          ),
          const SizedBox(height: 20),
          Text('Mode', style: Theme.of(context).textTheme.titleSmall),
          Wrap(
            spacing: 8,
            children: [
              ChoiceChip(
                label: const Text('Auto'),
                selected: _mode == null,
                onSelected: (_) => setState(() => _mode = null),
              ),
              for (final m in AnalyzeMode.values)
                ChoiceChip(
                  label: Text(m.name),
                  selected: _mode == m,
                  onSelected: (_) => setState(() => _mode = m),
                ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            'Speed  ${_speed.toStringAsFixed(2)}x',
            style: Theme.of(context).textTheme.titleSmall,
          ),
          Slider(
            value: _speed,
            min: 0.25,
            max: 1.0,
            divisions: 3,
            label: '${_speed.toStringAsFixed(2)}x',
            onChanged: (v) => setState(() => _speed = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Slow inference (trace arrives after 2.5 s)'),
            subtitle: const Text('Shows the looping scan line while waiting'),
            value: _slowInference,
            onChanged: (v) => setState(() => _slowInference = v),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _busy ? null : _run,
            child: const Text('Run'),
          ),
        ],
      ),
    );
  }

  /// A plain skin-toned picture with soft pink patches where the fixture's
  /// heat is, so the lit cells can be judged against something.
  Future<ImageProvider> _syntheticPhoto(String fixture) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder, const Rect.fromLTWH(0, 0, _w, _h));
    canvas.drawRect(
      const Rect.fromLTWH(0, 0, _w, _h),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset.zero,
          const Offset(_w, _h),
          const [Color(0xFFCFA97F), Color(0xFFB48A63), Color(0xFF8F6B4A)],
          const [0.0, 0.55, 1.0],
        ),
    );
    final rnd = math.Random(3);
    final fur = Paint()
      ..strokeWidth = 1.2
      ..color = const Color(0x223A2514);
    for (var i = 0; i < 1400; i++) {
      final x = rnd.nextDouble() * _w;
      final y = rnd.nextDouble() * _h;
      canvas.drawLine(
        Offset(x, y),
        Offset(x + rnd.nextDouble() * 6 - 3, y + 16 + rnd.nextDouble() * 28),
        fur,
      );
    }
    final blobs = FixtureCams.blobs[fixture];
    final patch = Paint()
      ..color = const Color(0xB0B9807A)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);
    if (blobs != null) {
      for (final b in blobs) {
        canvas.drawOval(
          Rect.fromCenter(
            center: Offset(
              b[0] / FixtureCams.size * _w,
              b[1] / FixtureCams.size * _h,
            ),
            width: b[2] * _w / FixtureCams.size * 2.2,
            height: b[2] * _h / FixtureCams.size * 2.2,
          ),
          patch,
        );
      }
    }
    final picture = recorder.endRecording();
    final image = await picture.toImage(_w.toInt(), _h.toInt());
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    return MemoryImage(bytes!.buffer.asUint8List());
  }
}
