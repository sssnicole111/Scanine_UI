import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import '../domain/analyze_timeline.dart';
import '../domain/heat_grid.dart';

/// Behaviour switches of the Analyzing screen.
@immutable
class AnalyzingConfig {
  const AnalyzingConfig({
    this.speed = 1.0,
    this.forceMode,
    this.detectLowEnd = !kDebugMode,
    this.resultOverlayOpacity = HeatGrid.maxCellAlpha,
    this.resultScrimFactor = 0.0,
    this.heroTag = AnalyzingHeroTags.photo,
  });

  /// 1.0 = real time. The debug route lowers it to slow the animation down.
  final double speed;

  /// Forces a mode (debug route and tests). Null = decide from the device.
  final AnalyzeMode? forceMode;

  /// Switch to the low-end timeline when the first frames are slow. Off in
  /// debug builds, where frame times are meaningless.
  final bool detectLowEnd;

  /// Opacity of the smooth overlay the cells blend into during the hand-off.
  /// Set it to the opacity the Result screen draws its Grad-CAM overlay with,
  /// so there is no jump. The default matches the lit cells.
  final double resultOverlayOpacity;

  /// How much of the navy scrim is still there when the hand-off ends
  /// (0 = gone, 1 = full). Match it to what the Result screen shows.
  final double resultScrimFactor;

  /// Hero tag of the photo; give the Result screen's photo the same tag.
  final Object heroTag;
}

abstract final class AnalyzingHeroTags {
  static const String photo = 'scanine.analyzing.photo';
}

/// State shared between the screen and its three painters. Painters read it
/// while painting; nothing here calls setState per frame.
class AnalyzeClock {
  AnalyzeClock({
    required this.main,
    required this.loop,
    required this.columns,
    required this.rows,
    required this.config,
    required this.mode,
    required this.onError,
  }) : repaint = Listenable.merge([main, loop]);

  /// 0..1 over the reference timeline.
  final Animation<double> main;

  /// 0..1 loop of the scan line while the trace is still being computed.
  final Animation<double> loop;

  final int columns;
  final int rows;
  final AnalyzingConfig config;
  final void Function(Object error, StackTrace stack) onError;

  /// Repaint trigger for the painters.
  final Listenable repaint;

  AnalyzeMode mode;

  /// True while waiting for inference: loop the scan line, light nothing.
  bool waiting = false;

  HeatGrid? grid;

  /// Smooth 56x56 version of the heat (white, alpha = heat) for the hand-off.
  ui.Image? overlay;

  bool _errored = false;

  AnalyzeFrame frame() => AnalyzeTimeline.frameAt(
    main.value,
    mode: mode,
    waitLoop: waiting ? loop.value : null,
  );

  /// Runs painter code; a failure is reported once and never crashes.
  void guard(VoidCallback body) {
    try {
      body();
    } catch (e, s) {
      if (_errored) return;
      _errored = true;
      onError(e, s);
    }
  }
}
