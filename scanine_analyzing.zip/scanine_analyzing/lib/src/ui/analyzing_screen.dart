import 'dart:async';
import 'dart:developer' as developer;

import 'package:flutter/material.dart';

import '../domain/analyze_timeline.dart';
import '../domain/heat_grid.dart';
import '../domain/scan_trace.dart';
import 'analyze_clock.dart';
import 'analyzing_tokens.dart';
import 'frame_painter.dart';
import 'grid_painter.dart';
import 'heat_overlay_image.dart';
import 'heat_scan_painter.dart';

/// The screen between Capture and Result.
///
/// A grid is laid over the whole photo and a scan line sweeps down it; grid
/// cells light up where Grad-CAM found heat. Which cells light up, and how
/// brightly, comes from [trace] and nothing else.
///
/// The animation runs on its own clock (3.0 s, [kMinAnalyzeMs]):
///  * if [trace] completes sooner, all beats still play;
///  * if it takes longer, the screen parks after the intro and loops the scan
///    line, with no text and no fake progress, until the trace arrives.
///
/// When the last beat has played, [onFinished] is called once with the trace
/// (or [ScanTrace.empty] if something failed). Push Result from there.
class AnalyzingScreen extends StatefulWidget {
  const AnalyzingScreen({
    super.key,
    required this.photo,
    required this.photoSize,
    required this.trace,
    required this.onFinished,
    this.wordmark,
    this.config = const AnalyzingConfig(),
  });

  /// The full captured image. Not cropped. Wrap it in a [ResizeImage] (for
  /// example cacheWidth 1080) if the original is large.
  final ImageProvider photo;

  /// Pixel size of [photo] as displayed (after EXIF rotation). Only the
  /// aspect ratio is used.
  final Size photoSize;

  /// Completes with the trace once inference has finished.
  final Future<ScanTrace> trace;

  /// Called once, after the hand-off, with the screen's own context.
  final void Function(BuildContext context, ScanTrace trace) onFinished;

  /// The splash screen's own "scanine" wordmark widget. A plain-text stand-in
  /// is used when this is null; replace it, do not ship the stand-in.
  final Widget? wordmark;

  final AnalyzingConfig config;

  @override
  State<AnalyzingScreen> createState() => _AnalyzingScreenState();
}

class _AnalyzingScreenState extends State<AnalyzingScreen>
    with TickerProviderStateMixin {
  static const String _disclaimer =
      'Preliminary screening only. Not a veterinary diagnosis.';

  late final AnimationController _main = AnimationController(vsync: this);
  late final AnimationController _loop = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1200),
  );
  late final AnalyzeClock _clock;

  ScanTrace? _trace;
  bool _traceReady = false;
  bool _introDone = false;
  bool _resumed = false;
  bool _finished = false;
  bool _failed = false;
  bool _started = false;

  // Low-end detection: average frame interval over the first 10 frames.
  final Stopwatch _sw = Stopwatch()..start();
  int _lastUs = -1;
  int _samples = 0;
  int _sumUs = 0;

  double get _speed => widget.config.speed <= 0 ? 1.0 : widget.config.speed;

  int _totalMs(AnalyzeMode mode) {
    switch (mode) {
      case AnalyzeMode.normal:
        return kMinAnalyzeMs;
      case AnalyzeMode.lowEnd:
        return kLowEndAnalyzeMs;
      case AnalyzeMode.reduced:
        return kReducedMotionMs;
    }
  }

  Duration _ms(num ms) => Duration(milliseconds: (ms / _speed).round());

  @override
  void initState() {
    super.initState();
    final aspect = widget.photoSize.height / widget.photoSize.width;
    _clock = AnalyzeClock(
      main: _main,
      loop: _loop,
      columns: HeatGrid.defaultColumns,
      rows: HeatGrid.rowsFor(aspect),
      config: widget.config,
      mode: widget.config.forceMode ?? AnalyzeMode.normal,
      onError: _onPaintError,
    );
    _main.addListener(_sampleFrameTime);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (widget.config.forceMode == null &&
        MediaQuery.of(context).disableAnimations) {
      _clock.mode = AnalyzeMode.reduced;
    }
    _begin();
  }

  void _begin() {
    unawaited(
      widget.trace.then(_onTrace).catchError((Object e, StackTrace s) {
        _fail(e, s);
      }),
    );
    if (_clock.mode == AnalyzeMode.reduced) {
      _introDone = true; // no intro in reduced motion
      return;
    }
    // Intro: scrim, grid and frame. Then wait for the trace if needed.
    unawaited(
      _main
          .animateTo(
            AnalyzeTimeline.introEnd,
            duration: _ms(AnalyzeTimeline.frameEnd * 1000),
            curve: Curves.linear,
          )
          .whenComplete(() {
            if (!mounted) return;
            _introDone = true;
            _maybeResume();
          }),
    );
  }

  Future<void> _onTrace(ScanTrace trace) async {
    try {
      final grid = HeatGrid.fromTrace(
        trace,
        aspect: widget.photoSize.height / widget.photoSize.width,
      );
      final overlay = trace.diffuse
          ? null
          : await HeatOverlayImage.fromTrace(trace, r: 0xF4, g: 0xF5, b: 0xFA);
      if (!mounted) {
        overlay?.dispose();
        return;
      }
      _clock.grid = grid;
      _clock.overlay = overlay;
      _trace = trace;
      _traceReady = true;
      _maybeResume();
    } catch (e, s) {
      _fail(e, s);
    }
  }

  void _maybeResume() {
    if (!mounted || _failed || _resumed) return;
    if (!_introDone) return;
    if (!_traceReady) {
      // Inference is slower than the intro: loop the scan line, nothing else.
      if (_clock.mode != AnalyzeMode.reduced && !_clock.waiting) {
        _clock.waiting = true;
        _loop.repeat();
      }
      return;
    }
    _resumed = true;
    _clock.waiting = false;
    _loop.stop();
    _runToEnd();
  }

  /// Plays the rest of the timeline from wherever the controller is now.
  void _runToEnd() {
    final remaining = (1.0 - _main.value).clamp(0.0, 1.0);
    unawaited(
      _main
          .animateTo(
            1.0,
            duration: _ms(remaining * _totalMs(_clock.mode)),
            curve: Curves.linear,
          )
          .whenComplete(_complete),
    );
  }

  void _complete() {
    if (!mounted || _failed || _finished) return;
    _finished = true;
    widget.onFinished(context, _trace ?? ScanTrace.empty());
  }

  /// Slow device? Average the first 10 frame intervals of the intro.
  void _sampleFrameTime() {
    if (!widget.config.detectLowEnd ||
        widget.config.forceMode != null ||
        _clock.mode != AnalyzeMode.normal ||
        _samples >= 10) {
      return;
    }
    final now = _sw.elapsedMicroseconds;
    if (_lastUs >= 0) {
      _sumUs += now - _lastUs;
      _samples++;
      if (_samples == 10 && _sumUs / 10 > 20000) {
        _clock.mode = AnalyzeMode.lowEnd;
        // Already playing the second half? Re-time what is left to about 2 s.
        if (_resumed && _main.isAnimating) _runToEnd();
      }
    }
    _lastUs = now;
  }

  void _onPaintError(Object e, StackTrace s) {
    WidgetsBinding.instance.addPostFrameCallback((_) => _fail(e, s));
  }

  /// Any failure: plain navy spinner, log it, never crash, move on.
  void _fail(Object e, StackTrace s) {
    developer.log(
      'Analyzing screen failed; falling back to a spinner.',
      name: 'scanine.analyzing',
      error: e,
      stackTrace: s,
    );
    if (!mounted || _failed) return;
    _loop.stop();
    _main.stop();
    setState(() => _failed = true);
    unawaited(
      Future<void>.delayed(const Duration(milliseconds: 400), () {
        if (!mounted || _finished) return;
        _finished = true;
        widget.onFinished(context, _trace ?? ScanTrace.empty());
      }),
    );
  }

  @override
  void dispose() {
    _main.removeListener(_sampleFrameTime);
    _main.dispose();
    _loop.dispose();
    _clock.overlay?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tokens = AnalyzingTokens.of(context);
    return Scaffold(
      backgroundColor: tokens.cloud,
      body: Semantics(
        // The only thing TalkBack hears: one polite announcement.
        liveRegion: true,
        label: 'Analyzing photo.',
        child: ExcludeSemantics(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                radius: 1.1,
                colors: [tokens.cloud, tokens.cloudDeep],
              ),
            ),
            child: _failed
                ? Center(child: CircularProgressIndicator(color: tokens.navy))
                : _content(tokens),
          ),
        ),
      ),
    );
  }

  Widget _content(AnalyzingTokens tokens) {
    return SafeArea(
      child: Column(
        children: [
          const SizedBox(height: 20),
          Center(child: widget.wordmark ?? _StandInWordmark(tokens: tokens)),
          const SizedBox(height: 20),
          Expanded(
            child: LayoutBuilder(
              builder: (context, box) {
                final size = _fit(box.biggest);
                return Center(
                  child: SizedBox(
                    width: size.width,
                    height: size.height,
                    child: _stage(tokens),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 16),
            child: Text(
              _disclaimer,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, height: 1.3, color: tokens.slate),
            ),
          ),
        ],
      ),
    );
  }

  /// Whole photo at its true aspect: full width, scaled down only if the
  /// height does not fit. Never cropped.
  Size _fit(Size max) {
    final aspect = widget.photoSize.width / widget.photoSize.height;
    var w = max.width;
    var h = w / aspect;
    if (h > max.height) {
      h = max.height;
      w = h * aspect;
    }
    return Size(w, h);
  }

  Widget _stage(AnalyzingTokens tokens) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Hero(
          tag: widget.config.heroTag,
          child: Image(
            image: widget.photo,
            fit: BoxFit.fill, // the box already has the photo's aspect
            filterQuality: FilterQuality.medium,
            gaplessPlayback: true,
          ),
        ),
        RepaintBoundary(
          child: CustomPaint(
            painter: GridPainter(clock: _clock, tokens: tokens),
          ),
        ),
        RepaintBoundary(
          child: CustomPaint(
            painter: HeatScanPainter(clock: _clock, tokens: tokens),
          ),
        ),
        RepaintBoundary(
          child: CustomPaint(
            painter: FramePainter(clock: _clock, tokens: tokens),
          ),
        ),
      ],
    );
  }
}

/// Plain-text stand-in so the screen runs on its own. The real screen must
/// use the splash screen's wordmark (same typeface, weight, colour, spacing).
class _StandInWordmark extends StatelessWidget {
  const _StandInWordmark({required this.tokens});

  final AnalyzingTokens tokens;

  @override
  Widget build(BuildContext context) {
    return Text(
      'scanine',
      style: TextStyle(
        fontFamily: 'Outfit',
        fontSize: 32,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.5,
        color: tokens.navy,
      ),
    );
  }
}
