import 'package:flutter/material.dart';

/// Fade route used to open Analyzing and to leave it for Result. The photo
/// is a [Hero] (same tag on both screens), so it stays exactly in place while
/// only the surrounding UI cross-fades.
Route<T> analyzingFadeRoute<T>(
  WidgetBuilder builder, {
  Duration duration = const Duration(milliseconds: 320),
}) {
  return PageRouteBuilder<T>(
    transitionDuration: duration,
    reverseTransitionDuration: duration,
    pageBuilder: (context, _, __) => builder(context),
    transitionsBuilder: (context, animation, _, child) => FadeTransition(
      opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
      child: child,
    ),
  );
}
