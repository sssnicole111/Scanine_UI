# scanine_analyzing

The **Analyzing** screen for Scanine: it sits between Capture and Result. A grid is laid over the user's whole photo and a scan line sweeps down it. Grid cells light up where Grad-CAM found heat, so the user sees the areas the model is looking at. Which cells light up, and how brightly, comes from the heatmap computed for that photo. No outlines, no labels, no text on the photo. The lit cells are the identification.

Splash palette only (navy, cloud, slate, scan grey). Heat is shown as light, never as a colour.

## What is verified and what is not

| Part | Status |
| --- | --- |
| `ScanTrace`, `InputMapping`, `HeatGrid`, `AnalyzeTimeline`, fixtures (all pure Dart, under `lib/src/domain` and `lib/src/debug/fixture_cams.dart`) | Compiled and **33 unit tests passed** on a real Dart SDK (3.13) |
| Painters, `AnalyzingScreen`, tokens, route, debug page (Flutter code) | **Not compiled.** There was no Flutter SDK where this was written. Syntax-checked and formatted with the Dart analyzer only. Expect to fix small API or lint issues on first build |
| 50 fps on a 3 GB Android 8 device | **Not measured** |
| Palette | Sampled from the splash video. Replace with your real theme tokens (see Tokens) |
| Wordmark | A stand-in `Text`. Pass the splash's own wordmark widget |

Run the tests in your project: `flutter test`.

## Install

Copy the folder next to your app (for example `packages/scanine_analyzing`) and add:

```yaml
dependencies:
  scanine_analyzing:
    path: packages/scanine_analyzing
```

No new third-party packages. Fully offline. Needs Dart 3.3+ / Flutter 3.19+.

## Wiring: Capture, Analyzing, Result

Build the trace **once, at the end of inference**. `ScanTrace.fromCam` is pure Dart (only `dart:typed_data`), so call it inside the inference isolate and send the result back (a `Uint8List` transfers cheaply).

```dart
// In the inference isolate, after the 5-frame vote, for the SAME frame the
// Result overlay uses:
final trace = ScanTrace.fromCam(
  cam: rawGradCam,            // e.g. Float32List of 7*7
  camWidth: 7,
  camHeight: 7,
  mapping: InputMapping.centerCrop(   // match your preprocessing exactly:
    imageWidth: frame.width,          //   stretch  -> InputMapping.stretch()
    imageHeight: frame.height,        //   crop     -> InputMapping.centerCrop(...)
    inputWidth: 224,                  //   letterbox-> InputMapping.letterbox(...)
    inputHeight: 224,
  ),
);
```

```dart
// On the capture screen:
final traceFuture = inference.run(frames); // Future<ScanTrace>, built as above

Navigator.of(context).push(analyzingFadeRoute((_) => AnalyzingScreen(
      photo: ResizeImage(FileImage(file), width: 1080),
      photoSize: Size(w, h),           // after EXIF rotation
      trace: traceFuture,
      wordmark: const SplashWordmark(), // the splash screen's own widget
      onFinished: (context, trace) {
        Navigator.of(context).pushReplacement(analyzingFadeRoute(
          (_) => ResultScreen(result: result, trace: trace),
        ));
      },
    )));
```

On Result:

* Wrap the photo in `Hero(tag: AnalyzingHeroTags.photo, ...)` so it stays exactly in place. If Result shows it at another size, the Hero animates between the two.
* Reuse the trace; do not recompute Grad-CAM. `HeatOverlayImage.fromTrace(trace)` gives the same smooth 56x56 overlay the hand-off ends on. Draw it stretched over the photo with `FilterQuality.high`.
* A trace with `diffuse == true` (or `ScanTrace.empty()`) means: draw no overlay. Result keeps handling abstain as it does today.
* Release the trace when Result closes.

## ScanTrace contract

```dart
class ScanTrace {
  final Uint8List heat;   // 56x56, row-major, 0..255, over the FULL captured image
  final double coverage;  // fraction of seen cells >= 0.5 of the maximum
  final bool diffuse;     // nothing stands out
}
```

`ScanTrace.fromCam` does, in order:

1. ReLU (NaN and infinities count as 0), divide by the maximum. A maximum below 1e-6 gives `ScanTrace.empty()` (diffuse, all zero).
2. Bilinear-upsample onto the 56x56 grid **through `InputMapping`**, which undoes the inference's resize, crop or letterbox so the heat lands on the whole photo. Cells the model never saw (cropped away, letterbox padding) are 0.
3. `coverage` counts cells >= 0.5 among the cells the model saw. `diffuse` is true when coverage is above 0.6 or nothing is lit.

If your preprocessing is something else (crop then pad, say), build `InputMapping(seen: ..., placed: ...)` by hand. `seen` is the part of the photo the model sees (0..1 of the photo), `placed` is where that part lands in the model input (0..1 of the input).

Note on resolution: a 7x7 Grad-CAM is coarse. Two lesions that are close together will merge into one lit area on the grid. That is what the model actually produced, so the screen shows it as is.

## Screen and timeline

Portrait, radial cloud background. From top to bottom: the "scanine" wordmark, the photo (full width, uncropped, true aspect ratio, scaled down only if the height does not fit), and the slate disclaimer line. TalkBack hears one polite announcement: "Analyzing photo."

Layers over the photo, back to front, on a 3.0 s clock (`kMinAnalyzeMs`):

| Time (s) | Beat |
| --- | --- |
| 0.0 - 0.45 | Navy scrim fades to 42 %. Grid (14 columns, square-ish cells, rows follow the photo height) draws outward from the centre, with light centre axes |
| 0.1 - 0.5 | Rounded corner brackets fade in (inset 14, arm 28, radius 10, 2 dp, round caps, plus 8 dp mid-edge ticks at 50 %). They stay to the end |
| 0.5 - 1.7 | Scan line (2 dp cloud line, soft grey glow) sweeps top to bottom, ease-in-out. Heat cells (>= 0.18 of max, cloud at alpha = heat x 0.66) light row by row as it passes |
| 1.7 - 2.4 | Hold |
| 2.4 - 3.0 | Hand-off: grid and scan fade, cells melt into one smooth overlay, then `onFinished` |

The animation runs on its own clock:

* Inference faster than the animation: all beats still play.
* Inference slower: the screen parks after the intro (0.5 s) and loops the scan line, with no text and no fake progress, then plays the rest once the trace arrives.

## States

* **Normal**: as above, one cluster or several.
* **Diffuse or empty**: grid and scan only, nothing lit, no text, then on to Result.
* **Low confidence**: cells light as normal. Abstain is decided and shown on Result only.
* **Reduced motion** (`MediaQuery.disableAnimations`): no sweep, no stagger. 0.6 s cross-fade to the final composition.
* **Low-end**: if the average frame interval over the first 10 frames is above 20 ms, the glow blur and the cell stagger are dropped and the screen finishes in about 2 s. Detection is off in debug builds (their frame times mean nothing). `AnalyzingConfig(detectLowEnd: ...)` overrides it.
* **Error** while building or drawing: plain navy spinner, the error is logged (`scanine.analyzing`), and `onFinished` still fires with `ScanTrace.empty()`. It never crashes.

## Tokens

`AnalyzingTokens` (a `ThemeExtension`) holds the colours. If your app already has theme tokens for navy, cloud and slate, register an instance built from them:

```dart
ThemeData(extensions: [
  AnalyzingTokens.splash.copyWith(navy: appNavy, cloud: appCloud, slate: appSlate),
]);
```

The defaults are the values sampled from the splash video: navy `#203661`, cloud `#F4F5FA` to `#E8EBF2`, slate `#6B7090`, scan grey `#C4CAD8`. The only new tokens are `gridLine`, `gridAxis` and `stageScrim`.

Two settings in `AnalyzingConfig` make the hand-off line up with Result: `resultOverlayOpacity` (default 0.66, the lit-cell opacity) and `resultScrimFactor` (default 0). Set them to what Result really draws. If Result's overlay uses colours outside the splash palette, restyle it, otherwise the hand-off will jump.

## Performance notes

One `AnimationController` (3.0 s), no `setState` per frame. Three `CustomPainter`s, each in its own `RepaintBoundary`. The grid is two cached `Path`s, so a frame is two `drawPath` calls. Cells are at most about 266 rects (14 x 19 for a 3:4 photo). The one `MaskFilter.blur` is on the scan line and is skipped in low-end mode. No `Opacity` widgets; alpha is applied inside the painters. Heat is sampled once per cell when the trace arrives.

## Debug route

`AnalyzingDebugPage` runs the screen on four built-in fixtures (one cluster, several clusters, diffuse, empty), with a speed slider from 0.25x to 1x, a mode switch (auto, normal, lowEnd, reduced) and a "slow inference" switch that shows the looping scan. Register it only in debug builds:

```dart
routes: {
  if (kDebugMode) '/debug/analyzing': (_) => const AnalyzingDebugPage(),
},
```

## Things to check on the first run

1. `HeatOverlayImage` writes premultiplied RGBA. If the smooth overlay looks too bright or too dim at its soft edges, premultiplication is the first suspect (the line is marked in `heat_overlay_image.dart`).
2. Hand-off: compare the last Analyzing frame with the first Result frame. Fix `resultOverlayOpacity` and `resultScrimFactor`.
3. The wordmark must be the splash's own widget.
4. On a tall phone a 3:4 photo leaves cloud bands above and below. That is intended (no crop).
5. Measure the sweep on a real 3 GB Android 8 device in profile mode.

## Layout

```
lib/
  scanine_analyzing.dart            barrel
  src/domain/                       pure Dart (no Flutter): ScanTrace, InputMapping,
                                    HeatGrid, AnalyzeTimeline
  src/ui/                           AnalyzingScreen, painters, tokens, route, overlay image
  src/debug/                        fixtures (pure) and the debug page
test/                               unit tests for everything in src/domain
```
