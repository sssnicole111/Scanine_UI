import 'dart:io';

import 'package:flutter/material.dart';

import '../models/screening_result.dart';
import '../theme/tokens.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key, required this.result});

  final ScreeningResult result;

  String get _timestamp {
    final now = DateTime.now();
    final h = now.hour % 12 == 0 ? 12 : now.hour % 12;
    final m = now.minute.toString().padLeft(2, '0');
    return 'Today · $h:$m ${now.hour < 12 ? 'AM' : 'PM'}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: T.bg,
      body: SafeArea(
        child: Column(
          children: [
            _TopBar(timestamp: _timestamp),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(T.s5, 0, T.s5, T.s5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _HeroCard(result: result),
                    const SizedBox(height: T.s4),
                    _VoteLine(result: result),
                    const SizedBox(height: T.s4),
                    _GuidanceCard(guidance: result.guidance),
                    const SizedBox(height: T.s4),
                    const Text(
                      'Scanine is a triage aid only. Not a veterinary diagnosis.',
                      style: TextStyle(fontSize: T.tXs, color: T.ink3),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(T.s5, 0, T.s5, T.s5),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () =>
                      Navigator.of(context).popUntil((r) => r.isFirst),
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFEF4444),
                    padding: const EdgeInsets.symmetric(vertical: T.s4),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(T.rFull),
                    ),
                    textStyle: const TextStyle(
                      fontSize: T.tBase,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(result.referralText),
                      const SizedBox(width: T.s2),
                      const Icon(Icons.arrow_forward, size: 16),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.timestamp});

  final String timestamp;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(T.s5, T.s4, T.s5, T.s3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
            customBorder: const CircleBorder(),
            child: Container(
              width: 32,
              height: 32,
              decoration: const BoxDecoration(
                color: T.surface,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.chevron_left, size: 20, color: T.ink),
            ),
          ),
          Row(
            children: [
              Text(
                timestamp,
                style: const TextStyle(
                  fontSize: T.tSm,
                  color: T.ink3,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(width: T.s2),
              _PendingBadge(),
            ],
          ),
        ],
      ),
    );
  }
}

/// The quiet "two conditions still in development" marker.
class _PendingBadge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => showModalBottomSheet<void>(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (_) => const _PendingSheet(),
      ),
      customBorder: const CircleBorder(),
      child: const SizedBox(
        width: 22,
        height: 22,
        child: Icon(Icons.error_outline, size: 15, color: T.ink3),
      ),
    );
  }
}

class _PendingSheet extends StatelessWidget {
  const _PendingSheet();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: T.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(T.rLg)),
      ),
      padding: const EdgeInsets.fromLTRB(T.s5, T.s3, T.s5, T.s6),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0x24101B34),
                  borderRadius: BorderRadius.circular(T.rFull),
                ),
              ),
            ),
            const SizedBox(height: T.s5),
            const Text(
              'In development',
              style: TextStyle(
                fontSize: T.tBase,
                fontWeight: FontWeight.w700,
                color: T.ink,
              ),
            ),
            const SizedBox(height: T.s2),
            const Text(
              'Scanine currently reports ringworm and dermatologically '
              'normal skin. Two conditions from the full model are still '
              'being trained:',
              style: TextStyle(fontSize: T.tSm, color: T.ink2, height: 1.5),
            ),
            const SizedBox(height: T.s4),
            ...kPendingClasses.map(
              (c) => Padding(
                padding: const EdgeInsets.only(bottom: T.s3),
                child: Container(
                  padding: const EdgeInsets.only(left: T.s3),
                  decoration: const BoxDecoration(
                    border: Border(
                      left: BorderSide(color: T.amber, width: 2),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        c.name,
                        style: const TextStyle(
                          fontSize: T.tSm,
                          fontWeight: FontWeight.w600,
                          color: T.ink,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        c.description,
                        style: const TextStyle(
                          fontSize: T.tXs,
                          color: T.ink3,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: T.s2),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () => Navigator.of(context).pop(),
                style: TextButton.styleFrom(
                  backgroundColor: T.bg,
                  foregroundColor: T.ink,
                  padding: const EdgeInsets.symmetric(vertical: T.s3),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(T.rFull),
                  ),
                ),
                child: const Text('Got it'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.result});

  final ScreeningResult result;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(T.rLg),
      child: SizedBox(
        height: 320,
        width: double.infinity,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (result.imagePath != null)
              Image.file(File(result.imagePath!), fit: BoxFit.cover)
            else
              Container(
                decoration: const BoxDecoration(gradient: T.cardGradient),
              ),
            // Scrim so the condition text stays legible.
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Color(0xCC000000), Color(0x00000000)],
                  stops: [0.0, 0.55],
                ),
              ),
            ),
            Positioned(
              top: T.s3,
              right: T.s3,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: T.s3, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xB3000000),
                  borderRadius: BorderRadius.circular(T.rFull),
                ),
                child: Text(
                  '${result.confidencePercent}%',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: T.tSm,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            Positioned(
              left: T.s5,
              right: T.s5,
              bottom: T.s5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    result.condition,
                    style: const TextStyle(
                      fontSize: T.tXl,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      letterSpacing: -0.32,
                    ),
                  ),
                  Text(
                    result.conditionLabel,
                    style: const TextStyle(
                      fontSize: T.tBase,
                      color: Color(0xCCFFFFFF),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _VoteLine extends StatelessWidget {
  const _VoteLine({required this.result});

  final ScreeningResult result;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 6,
          height: 6,
          decoration: const BoxDecoration(
            color: T.amber,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: T.s2),
        Expanded(
          child: Text(
            '${result.agreeVotes}/${result.totalFrames} frames agreed '
            'on ${result.condition}',
            style: const TextStyle(fontSize: T.tSm, color: T.ink2),
          ),
        ),
      ],
    );
  }
}

class _GuidanceCard extends StatelessWidget {
  const _GuidanceCard({required this.guidance});

  final List<String> guidance;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(T.s5),
      decoration: BoxDecoration(
        color: T.surface,
        borderRadius: BorderRadius.circular(T.rLg),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'FIRST-RESPONSE GUIDANCE',
            style: TextStyle(
              fontSize: T.tXs,
              fontWeight: FontWeight.w700,
              color: T.ink3,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: T.s4),
          ...guidance.map(
            (line) => Padding(
              padding: const EdgeInsets.only(bottom: T.s3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 2),
                    child: Icon(Icons.check, size: 15, color: T.success),
                  ),
                  const SizedBox(width: T.s3),
                  Expanded(
                    child: Text(
                      line,
                      style: const TextStyle(
                        fontSize: T.tSm,
                        color: T.ink,
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
